package com.capgemini;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages= {"com.capgemini"})
public class Day1SpringBootMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day1SpringBootMvcApplication.class, args);
	}
}
