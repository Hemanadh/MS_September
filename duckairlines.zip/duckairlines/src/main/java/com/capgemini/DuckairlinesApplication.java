package com.capgemini;

import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@ComponentScan("com.capgemini")
public class DuckairlinesApplication {

	private static Logger log = Logger.getLogger(DuckairlinesApplication.class);
	public static void main(String[] args) {
		log.info("Logger enabled: Entering main \n\n");
		SpringApplication.run(DuckairlinesApplication.class, args);
	}
}
